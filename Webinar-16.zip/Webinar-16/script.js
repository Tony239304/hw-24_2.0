

// returns function (callback)
function prepareFilterWithRange(from, to){
    return function (item){
        return item > from && item < to;
    };
    //return item > from && item < to;
}

const filterCallback = function (item){
    return item > 4 && item < 8;
};
const filterNewCallback = function (item){
    return item > 1 && item < 5;
};

const filter1to4 = prepareFilterWithRange(1, 4);
const filter5to9 = prepareFilterWithRange(6, 9);
const filter4to5 = prepareFilterWithRange(4, 6);
/*
function (item){
        return item > 1 && item < 4;
    };
* * */

const array = [3,2,6,7,2,4,1,3,5,2,1];

const resArray = array.filter(filter1to4);

console.log(resArray);

function arrayGenerator(length){
    const arrayMemory = [];

    return function (maxValue) {
        for(let i=0; i < length; i++){
            arrayMemory.push(
                +(Math.random()*maxValue).toFixed()
            );
        }
        return arrayMemory;
    }
}
const arrayGenerator10 = arrayGenerator(10);
const arrayRes = arrayGenerator10(100);
console.log(arrayRes);